### R code from vignette source 'CoDaSeq_vignette.Rnw'

###################################################
### code chunk number 1: CoDaSeq_vignette.Rnw:46-57
###################################################

library(CoDaSeq)
library(zCompositions)
data(ak_op)
data(hmpgenera)

# the first function is to subset the dataselex
f <- codaSeq.filter(ak_op, min.reads=1000, min.prop=0.01, max.prop=1,
    min.occurrence=0.25, samples.by.row=FALSE)

# this should leave 167 OTUs and 30 samples


###################################################
### code chunk number 2: CoDaSeq_vignette.Rnw:72-80
###################################################
# replace 0 values with an imputed value using the Count Zero Multiplicative method
# from the zCompositions package
# the table is transposed t() to make the samples by row
# all further analyses have this orientation
f.n0 <- cmultRepl(t(f), label=0, method="CZM")

# perform the centered log-ratio transformation
f.clr <- codaSeq.clr(f.n0, samples.by.row=TRUE)


###################################################
### code chunk number 3: CoDaSeq_vignette.Rnw:87-91
###################################################

# perform the singular value decomposition on clr transformed values
f.pcx <- prcomp(f.clr)
biplot(f.pcx, var.axes=FALSE, cex=c(0.5,0.6), scale=0)


###################################################
### code chunk number 4: CoDaSeq_vignette.Rnw:96-155
###################################################
rbcol=c("red", "blue")
grp = list(c(1:15), c(16:30))

par(mfrow=c(3,4))

label="ALL"
f <- codaSeq.filter(ak_op, min.reads=1000, samples.by.row=FALSE, min.count=1)
f.n0 <- cmultRepl(t(f), label=0, method="CZM")
# perform the centered log-ratio transformation
f.clr <- codaSeq.clr(f.n0, samples.by.row=TRUE)
f.pcx <- prcomp(f.clr)
codaSeq.PCAplot(f.pcx, main=label, plot.groups=TRUE, grp.col=rbcol, 
    grp=grp, plot.circles=TRUE, plot.loadings=TRUE)

label="min.count=100"
f <- codaSeq.filter(ak_op, min.reads=1000, min.count=10, samples.by.row=FALSE)
f.n0 <- cmultRepl(t(f), label=0, method="CZM")
# perform the centered log-ratio transformation
f.clr <- codaSeq.clr(f.n0, samples.by.row=TRUE)
f.pcx <- prcomp(f.clr)
codaSeq.PCAplot(f.pcx, main=label, plot.groups=TRUE, grp.col=rbcol, 
    grp=grp, plot.circles=TRUE, plot.loadings=TRUE)

label="min.prop=0.01"
f <- codaSeq.filter(ak_op, min.reads=1000, min.prop=0.01, samples.by.row=FALSE)
f.n0 <- cmultRepl(t(f), label=0, method="CZM")
# perform the centered log-ratio transformation
f.clr <- codaSeq.clr(f.n0, samples.by.row=TRUE)
f.pcx <- prcomp(f.clr)
codaSeq.PCAplot(f.pcx, main=label, plot.groups=TRUE, grp.col=rbcol, 
    grp=grp, plot.circles=TRUE, plot.loadings=TRUE)

label="max.prop=0.01"
f <- codaSeq.filter(ak_op, min.reads=1000, min.prop=0.001, max.prop=0.01, samples.by.row=FALSE)
f.n0 <- cmultRepl(t(f), label=0, method="CZM")
# perform the centered log-ratio transformation
f.clr <- codaSeq.clr(f.n0, samples.by.row=TRUE)
f.pcx <- prcomp(f.clr)
codaSeq.PCAplot(f.pcx, main=label, plot.groups=TRUE, grp.col=rbcol, 
    grp=grp, plot.circles=TRUE, plot.loadings=TRUE)

label="var.filt=TRUE"
f <- codaSeq.filter(ak_op, min.reads=1000, var.filt=TRUE, samples.by.row=FALSE)
f.n0 <- cmultRepl(t(f), label=0, method="CZM")
# perform the centered log-ratio transformation
f.clr <- codaSeq.clr(f.n0, samples.by.row=TRUE)
f.pcx <- prcomp(f.clr)
codaSeq.PCAplot(f.pcx, main=label, plot.groups=TRUE, grp.col=rbcol, 
    grp=grp, plot.circles=TRUE, plot.loadings=TRUE)

label="min.occurrence=0.5"
f <- codaSeq.filter(ak_op, min.reads=1000, min.occurrence=0.5, samples.by.row=FALSE)
f.n0 <- cmultRepl(t(f), label=0, method="CZM")
# perform the centered log-ratio transformation
f.clr <- codaSeq.clr(f.n0, samples.by.row=TRUE)
f.pcx <- prcomp(f.clr)
codaSeq.PCAplot(f.pcx, main=label, plot.groups=TRUE, grp.col=rbcol, 
    grp=grp, plot.circles=TRUE, plot.loadings=TRUE)



###################################################
### code chunk number 5: CoDaSeq_vignette.Rnw:164-175
###################################################

# perform the singular value decomposition on clr transformed values
conds <- c(rep("A", 15), rep("O", 15))

f.x <- aldex.clr(f, conds)
f.e <- aldex.effect(f.x, conds)
f.t <- aldex.ttest(f.x, conds)
f.all <- data.frame(f.e,f.t)

codaSeq.stripchart(aldex.out=f.all, group.table=hmpgenera, group.label="genus", 
    p.cutoff=0.05, x.axis="effect",mar=c(2,8,4,0.5))


