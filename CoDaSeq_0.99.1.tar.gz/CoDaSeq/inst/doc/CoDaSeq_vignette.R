### R code from vignette source 'CoDaSeq_vignette.Rnw'

###################################################
### code chunk number 1: CoDaSeq_vignette.Rnw:44-54
###################################################

library(CoDaSeq)
data(ak_op)
data(hmpgenera)

# the first function is to subset the dataselex
f <- codaSeq.filter(ak_op, min.reads=1000, min.prop=0.01, max.prop=1,
    min.occurrence=0.25, samples.by.row=FALSE)
    
# this should leave 167 OTUs and 30 samples


