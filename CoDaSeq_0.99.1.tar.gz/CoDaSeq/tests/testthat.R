library(testthat)
library(CoDaSeq)

test_check("CoDaSeq")
